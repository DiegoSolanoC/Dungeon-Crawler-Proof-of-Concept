package utilities;

import model.map.Map;

public class Collision {
    public static boolean isWalkable(Map map, int x, int y) {
        if (map == null) return false;
        if (x < 0 || y < 0 || x >= map.get_width() || y >= map.get_height()) return false;
        Tile tile = map.get_tile(x, y);
        return tile != null && tile.is_walkable();
    }
} 