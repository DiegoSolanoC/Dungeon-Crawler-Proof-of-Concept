package view;

import interfaces.GameController;
import interfaces.GameObserver;
import enums.GameState;
import model.characters.Player;
import model.map.Map;
import view.panels.GamePanel;
import view.panels.InventoryPanel;
import view.panels.MenuPanel;
import view.panels.BattlePanel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashSet;
import java.util.Set;

/**
* Main game view that manages different panel displays and handles user input.
* Implements the MVC View pattern with observer notifications for model changes.
*/
public class GameView extends JFrame implements interfaces.GameView, GameObserver, KeyListener {

// MANDATORY: View components
private GameController controller;
private GamePanel gamePanel;
private InventoryPanel inventoryPanel;
private MenuPanel menuPanel;
private BattlePanel battlePanel;
private CardLayout cardLayout;
private JPanel mainPanel;

// MANDATORY: Current display state
private GameState currentState;

// MANDATORY: Player reference for inventory panel
private Player currentPlayer;

private boolean debugMode = false;
private final Set<Integer> pressedMovementKeys = new HashSet<>();

/**
    * MANDATORY: Constructor for GameView
*/
public GameView() {
this.cardLayout = new CardLayout();
this.mainPanel = new JPanel(cardLayout);
this.currentState = GameState.MAIN_MENU;

initialize_components();
setup_window();
setup_input_handling();
}

/**
    * MANDATORY: Initialize all GUI components
*/
@Override
public void initialize_components() {
// Create panels
menuPanel = new MenuPanel(this);
gamePanel = new GamePanel(this);
inventoryPanel = new InventoryPanel(this);
battlePanel = new BattlePanel(this);

// Add panels to card layout
mainPanel.add(menuPanel, "MENU");
mainPanel.add(gamePanel, "GAME");
mainPanel.add(inventoryPanel, "INVENTORY");
mainPanel.add(battlePanel, "BATTLE");

add(mainPanel);
}

/**
    * MANDATORY: Setup main window properties
*/
private void setup_window() {
setTitle("Mini Rogue Demo");
setSize(enums.GameConstants.WINDOW_WIDTH, enums.GameConstants.WINDOW_HEIGHT);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLocationRelativeTo(null);
setResizable(false);

// Show menu panel initially
cardLayout.show(mainPanel, "MENU");
}

/**
    * MANDATORY: Setup keyboard input handling
*/
private void setup_input_handling() {
addKeyListener(this);
setFocusable(true);
requestFocusInWindow();
}

/**
    * MANDATORY: Update display based on current game state
*/
@Override
public void update_display() {
switch (currentState) {
case MAIN_MENU:
cardLayout.show(mainPanel, "MENU");
menuPanel.update_display();
requestFocusInWindow();
break;
case CLASS_SELECTION:
cardLayout.show(mainPanel, "MENU");
menuPanel.show_class_selection();
break;
case PLAYING:
cardLayout.show(mainPanel, "GAME");
gamePanel.update_display();
break;
case BATTLE:
cardLayout.show(mainPanel, "BATTLE");
battlePanel.update_display();
break;
case INVENTORY:
cardLayout.show(mainPanel, "INVENTORY");
inventoryPanel.set_player(currentPlayer);
inventoryPanel.update_display();
break;
case PAUSED:
gamePanel.show_pause_overlay();
mainPanel.requestFocusInWindow();
gamePanel.repaint();
break;
case GAME_OVER:
cardLayout.show(mainPanel, "MENU");
menuPanel.show_game_over();
break;
case VICTORY:
cardLayout.show(mainPanel, "MENU");
menuPanel.show_victory();
break;
}

repaint();
requestFocusInWindow();
}

/**
    * MANDATORY: Handle model change notifications
    * 
    * @param event Event type that occurred
    * @param data Data associated with the event
*/
@Override
public void on_model_changed(String event, Object data) {
SwingUtilities.invokeLater(() -> {
switch (event) {
case "GAME_STATE_CHANGED":
currentState = (GameState) data;
if (currentState == enums.GameState.MAIN_MENU) {
menuPanel.show_main_menu();
}
if (currentState == enums.GameState.PLAYING || currentState == enums.GameState.INVENTORY) {
    // Try to get player from model if possible
    try {
        currentPlayer = ((model.gameLogic.GameLogic)controller.get_model()).get_player();
    } catch (Exception ex) {}
}
update_display();
break;
case "GAME_PAUSED":
currentState = enums.GameState.PAUSED;
update_display();
break;
case "GAME_RESUMED":
currentState = enums.GameState.PLAYING;
update_display();
break;
case "PLAYER_MOVED":
gamePanel.update_player_position((utilities.Position) data);
break;
case "HP_CHANGED":
case "MP_CHANGED":
case "LEVEL_UP":
gamePanel.update_player_stats();
break;
case "INVENTORY_CHANGED":
inventoryPanel.update_inventory();
break;
case "BATTLE_INITIATED":
battlePanel.start_battle(data);
break;
case "BATTLE_ENDED":
update_display();
break;
case "MAP_GENERATED":
gamePanel.set_map((Map) data);
break;
}
});
}

/**
    * MANDATORY: Handle keyboard input for game controls
    * 
    * @param e KeyEvent from user input
*/
@Override
public void keyPressed(KeyEvent e) {
    if (controller == null) return;

    // Debug mode toggle (O key)
    if (currentState == GameState.PLAYING && e.getKeyCode() == KeyEvent.VK_O) {
        debugMode = !debugMode;
        gamePanel.set_debug_mode(debugMode);
        return;
    }

switch (currentState) {
case PLAYING:
handle_game_input(e);
break;
case BATTLE:
handle_battle_input(e);
break;
case INVENTORY:
    inventoryPanel.set_player(currentPlayer);
    handle_inventory_input(e);
    break;
case PAUSED:
    // Route key events to GamePanel's pause menu handler
    boolean handled = gamePanel.handlePauseMenuInput(e.getKeyCode());
    if (!handled && e.getKeyCode() == KeyEvent.VK_ESCAPE) {
        controller.handle_input("RESUME_GAME");
    }
    break;
case MAIN_MENU:
case CLASS_SELECTION:
case GAME_OVER:
case VICTORY:
handle_menu_input(e);
break;
}
}

/**
    * MANDATORY: Handle input during gameplay
    * 
    * @param e KeyEvent from user input
*/
private void handle_game_input(KeyEvent e) {
    if (currentPlayer == null) return;
    int code = e.getKeyCode();
    // Track pressed movement keys
    if (code == KeyEvent.VK_UP || code == KeyEvent.VK_W ||
        code == KeyEvent.VK_DOWN || code == KeyEvent.VK_S ||
        code == KeyEvent.VK_LEFT || code == KeyEvent.VK_A ||
        code == KeyEvent.VK_RIGHT || code == KeyEvent.VK_D) {
        pressedMovementKeys.add(code);
        updatePlayerMoveDirectionFromKeys();
        return;
    }
    switch (code) {
        case KeyEvent.VK_SPACE:
            controller.handle_input("ATTACK");
            break;
        case KeyEvent.VK_I:
            controller.handle_input("OPEN_INVENTORY");
            break;
        case KeyEvent.VK_ESCAPE:
            controller.handle_input("PAUSE");
            break;
    }
}

private void updatePlayerMoveDirectionFromKeys() {
    int dx = 0, dy = 0;
    if (pressedMovementKeys.contains(KeyEvent.VK_UP) || pressedMovementKeys.contains(KeyEvent.VK_W)) dy -= 1;
    if (pressedMovementKeys.contains(KeyEvent.VK_DOWN) || pressedMovementKeys.contains(KeyEvent.VK_S)) dy += 1;
    if (pressedMovementKeys.contains(KeyEvent.VK_LEFT) || pressedMovementKeys.contains(KeyEvent.VK_A)) dx -= 1;
    if (pressedMovementKeys.contains(KeyEvent.VK_RIGHT) || pressedMovementKeys.contains(KeyEvent.VK_D)) dx += 1;
    // Normalize for diagonal movement
    if (dx != 0 && dy != 0) {
        double norm = Math.sqrt(dx * dx + dy * dy);
        dx = (int)Math.round(dx / norm);
        dy = (int)Math.round(dy / norm);
    }
    currentPlayer.setMoveDirection(dx, dy);
}

/**
    * MANDATORY: Handle input during battle
    * 
    * @param e KeyEvent from user input
*/
private void handle_battle_input(KeyEvent e) {
String input = "";

switch (e.getKeyCode()) {
case KeyEvent.VK_SPACE:
input = "BATTLE_ATTACK";
break;
case KeyEvent.VK_R:
input = "BATTLE_RUN";
break;
case KeyEvent.VK_I:
input = "BATTLE_ITEM";
break;
}

if (!input.isEmpty()) {
controller.handle_input(input);
}
}

/**
    * MANDATORY: Handle input in inventory screen
    * 
    * @param e KeyEvent from user input
*/
private void handle_inventory_input(KeyEvent e) {
    switch (e.getKeyCode()) {
    case KeyEvent.VK_ESCAPE:
    case KeyEvent.VK_I:
        controller.handle_input("CLOSE_INVENTORY");
        currentState = GameState.PLAYING;
        update_display();
        break;
    case KeyEvent.VK_UP:
        inventoryPanel.move_selection_up();
        break;
    case KeyEvent.VK_DOWN:
        inventoryPanel.move_selection_down();
        break;
    case KeyEvent.VK_ENTER:
        inventoryPanel.use_selected_item();
        break;
    }
}

/**
    * MANDATORY: Handle input in menu screens
    * 
    * @param e KeyEvent from user input
*/
private void handle_menu_input(KeyEvent e) {
    switch (e.getKeyCode()) {
    case KeyEvent.VK_ENTER:
        menuPanel.select_current_option();
        break;
    case KeyEvent.VK_UP:
    case KeyEvent.VK_W:
        menuPanel.move_selection_up();
        break;
    case KeyEvent.VK_DOWN:
    case KeyEvent.VK_S:
        menuPanel.move_selection_down();
        break;
    case KeyEvent.VK_ESCAPE:
        menuPanel.go_back();
        if (currentState == GameState.MAIN_MENU) {
            controller.handle_input("BACK_TO_MENU");
        }
        break;
    }
}

@Override
public void keyReleased(KeyEvent e) {
    if (currentState == GameState.PLAYING && currentPlayer != null) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_UP || code == KeyEvent.VK_W ||
            code == KeyEvent.VK_DOWN || code == KeyEvent.VK_S ||
            code == KeyEvent.VK_LEFT || code == KeyEvent.VK_A ||
            code == KeyEvent.VK_RIGHT || code == KeyEvent.VK_D) {
            pressedMovementKeys.remove(code);
            updatePlayerMoveDirectionFromKeys();
        }
    }
}

@Override
public void keyTyped(KeyEvent e) {
// Not used in this implementation
}

// MANDATORY: Interface implementations
@Override
public GameController get_controller() {
return controller;
}

@Override
public void set_controller(GameController controller) {
this.controller = controller;
}

/**
    * MANDATORY: Get reference to game panel for controller access
    * 
    * @return The GamePanel instance
*/
public GamePanel get_game_panel() {
return gamePanel;
}

/**
    * MANDATORY: Get reference to battle panel for controller access
    * 
    * @return The BattlePanel instance
*/
public BattlePanel get_battle_panel() {
return battlePanel;
}

/**
    * MANDATORY: Show the main window
*/
public void show_window() {
setVisible(true);
setFocusable(true);
requestFocusInWindow();
}
} 