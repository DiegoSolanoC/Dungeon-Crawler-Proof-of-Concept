
package view.panels;

import view.GameView;
import model.characters.Player;
import model.items.Item;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class InventoryPanel extends JPanel {
    private GameView parentView;
    private Player player;
    private List<Item> items;
    private int selectedIndex = 0;

    public InventoryPanel(GameView parentView) {
        this.parentView = parentView;
        setBackground(Color.DARK_GRAY);
        setFocusable(false);
        setPreferredSize(new Dimension(1024, 768));
    }

    public void set_player(Player player) {
        this.player = player;
        if (player != null) {
            this.items = player.get_inventory();
        }
        if (items != null && !items.isEmpty() && selectedIndex >= items.size()) {
            selectedIndex = 0;
        }
        repaint();
    }

    public void update_inventory() {
        if (player != null) {
            this.items = player.get_inventory();
        }
        if (items != null && !items.isEmpty() && selectedIndex >= items.size()) {
            selectedIndex = 0;
        }
        repaint();
    }

    public void update_display() {
        update_inventory();
    }

    public void move_selection_up() {
        if (items == null || items.isEmpty()) return;
        selectedIndex = (selectedIndex - 1 + items.size()) % items.size();
        update_display();
    }

    public void move_selection_down() {
        if (items == null || items.isEmpty()) return;
        selectedIndex = (selectedIndex + 1) % items.size();
        update_display();
    }

    public void use_selected_item() {
        if (items == null || items.isEmpty()) return;
        Item item = items.get(selectedIndex);
        if (player != null && item != null) {
            player.use_item(item);
            update_inventory();
        }
    }

    public int getSelectedIndex() {
        return selectedIndex;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (items == null) return;
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 36));
        String title = "Inventory";
        int titleWidth = g2d.getFontMetrics().stringWidth(title);
        g2d.drawString(title, (getWidth() - titleWidth) / 2, 80);

        g2d.setFont(new Font("Arial", Font.PLAIN, 24));
        if (items == null || items.isEmpty()) {
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.drawString("No items in inventory.", 100, 160);
        }
        int startY = 140;
        for (int i = 0; items != null && i < items.size(); i++) {
            if (i == selectedIndex) {
                g2d.setColor(Color.YELLOW);
                g2d.fillRoundRect(80, startY + i * 40 - 28, 860, 36, 16, 16);
                g2d.setColor(Color.BLACK);
            } else {
                g2d.setColor(Color.LIGHT_GRAY);
            }
            String itemStr = items.get(i).get_name();
            g2d.drawString(itemStr, 100, startY + i * 40);
        }
        // Show details for selected item
        if (items != null && !items.isEmpty() && selectedIndex < items.size()) {
            Item selected = items.get(selectedIndex);
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.PLAIN, 20));
            g2d.drawString("Description: " + selected.get_description(), 100, 600);
        }
    }
} 