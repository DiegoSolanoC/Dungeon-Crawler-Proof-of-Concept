package view.panels;

import view.GameView;
import javax.swing.*;
import java.awt.*;

public class MenuPanel extends JPanel {
    private static final String[] MENU_OPTIONS = {"Start New Game", "Exit"};
    private static final String[] CLASS_OPTIONS = {"Warrior", "Mage", "Rogue"};
    private int selectedIndex = 0;
    private int classSelectedIndex = 0;
    private GameView parentView;
    private enum Mode { MAIN_MENU, CLASS_SELECTION }
    private Mode mode = Mode.MAIN_MENU;
    private static final int BACK_OPTION_INDEX = 3;
    private Rectangle backButtonBounds = new Rectangle();

    public MenuPanel(GameView parentView) {
        this.parentView = parentView;
        setFocusable(false);
        setBackground(Color.DARK_GRAY);
        setPreferredSize(new Dimension(1024, 768));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 48));
        String title = "Mini Rogue Demo";
        int titleWidth = g2d.getFontMetrics().stringWidth(title);
        g2d.drawString(title, (getWidth() - titleWidth) / 2, 150);

        g2d.setFont(new Font("Arial", Font.PLAIN, 32));
        if (mode == Mode.MAIN_MENU) {
            for (int i = 0; i < MENU_OPTIONS.length; i++) {
                if (i == selectedIndex) {
                    g2d.setColor(Color.YELLOW);
                } else {
                    g2d.setColor(Color.LIGHT_GRAY);
                }
                String option = MENU_OPTIONS[i];
                int optionWidth = g2d.getFontMetrics().stringWidth(option);
                g2d.drawString(option, (getWidth() - optionWidth) / 2, 300 + i * 60);
            }
        } else if (mode == Mode.CLASS_SELECTION) {
            g2d.setColor(Color.CYAN);
            String selectClass = "Select Character Class";
            int selectClassWidth = g2d.getFontMetrics().stringWidth(selectClass);
            g2d.drawString(selectClass, (getWidth() - selectClassWidth) / 2, 250);
            for (int i = 0; i < CLASS_OPTIONS.length; i++) {
                if (i == classSelectedIndex) {
                    g2d.setColor(Color.YELLOW);
                } else {
                    g2d.setColor(Color.LIGHT_GRAY);
                }
                String option = CLASS_OPTIONS[i];
                int optionWidth = g2d.getFontMetrics().stringWidth(option);
                g2d.drawString(option, (getWidth() - optionWidth) / 2, 350 + i * 60);
            }
            // Draw Back button
            int backY = 350 + CLASS_OPTIONS.length * 60 + 40;
            String backText = "Back";
            g2d.setFont(new Font("Arial", Font.PLAIN, 28));
            int backWidth = g2d.getFontMetrics().stringWidth(backText);
            int backX = (getWidth() - backWidth) / 2;
            backButtonBounds.setBounds(backX - 20, backY - 32, backWidth + 40, 40);
            if (classSelectedIndex == BACK_OPTION_INDEX) {
                g2d.setColor(Color.YELLOW);
            } else {
                g2d.setColor(Color.LIGHT_GRAY);
            }
            g2d.drawRect(backX - 20, backY - 32, backWidth + 40, 40);
            g2d.drawString(backText, backX, backY);
        }
    }

    public void update_display() {
        repaint();
    }

    public void show_class_selection() {
        mode = Mode.CLASS_SELECTION;
        classSelectedIndex = 0;
        repaint();
    }

    public void show_game_over() {
        mode = Mode.MAIN_MENU;
        repaint();
    }

    public void show_victory() {
        mode = Mode.MAIN_MENU;
        repaint();
    }

    public void show_main_menu() {
        mode = Mode.MAIN_MENU;
        selectedIndex = 0;
        repaint();
    }

    public void select_current_option() {
        if (mode == Mode.MAIN_MENU) {
            if (selectedIndex == 0) {
                parentView.get_controller().handle_input("START_NEW_GAME");
            } else if (selectedIndex == 1) {
                parentView.get_controller().handle_input("EXIT_APPLICATION");
            }
        } else if (mode == Mode.CLASS_SELECTION) {
            if (classSelectedIndex == 0) {
                parentView.get_controller().handle_input("SELECT_WARRIOR");
            } else if (classSelectedIndex == 1) {
                parentView.get_controller().handle_input("SELECT_MAGE");
            } else if (classSelectedIndex == 2) {
                parentView.get_controller().handle_input("SELECT_ROGUE");
            } else if (classSelectedIndex == BACK_OPTION_INDEX) {
                go_back();
            }
        }
    }

    public void move_selection_up() {
        if (mode == Mode.MAIN_MENU) {
            selectedIndex = (selectedIndex - 1 + MENU_OPTIONS.length) % MENU_OPTIONS.length;
        } else if (mode == Mode.CLASS_SELECTION) {
            classSelectedIndex = (classSelectedIndex - 1 + (CLASS_OPTIONS.length + 1)) % (CLASS_OPTIONS.length + 1);
        }
        repaint();
    }

    public void move_selection_down() {
        if (mode == Mode.MAIN_MENU) {
            selectedIndex = (selectedIndex + 1) % MENU_OPTIONS.length;
        } else if (mode == Mode.CLASS_SELECTION) {
            classSelectedIndex = (classSelectedIndex + 1) % (CLASS_OPTIONS.length + 1);
        }
        repaint();
    }

    // Mouse support for Back button
    @Override
    protected void processMouseEvent(java.awt.event.MouseEvent e) {
        if (e.getID() == java.awt.event.MouseEvent.MOUSE_CLICKED) {
            if (mode == Mode.MAIN_MENU) {
                // Detect click on main menu options
                for (int i = 0; i < MENU_OPTIONS.length; i++) {
                    int optionY = 300 + i * 60;
                    int optionHeight = 40;
                    int optionWidth = getFontMetrics(new Font("Arial", Font.PLAIN, 32)).stringWidth(MENU_OPTIONS[i]);
                    int optionX = (getWidth() - optionWidth) / 2;
                    Rectangle optionRect = new Rectangle(optionX - 20, optionY - 32, optionWidth + 40, optionHeight);
                    if (optionRect.contains(e.getPoint())) {
                        selectedIndex = i;
                        repaint();
                        select_current_option();
                        return;
                    }
                }
            } else if (mode == Mode.CLASS_SELECTION) {
                // Detect click on class options
                for (int i = 0; i < CLASS_OPTIONS.length; i++) {
                    int optionY = 350 + i * 60;
                    int optionHeight = 40;
                    int optionWidth = getFontMetrics(new Font("Arial", Font.PLAIN, 32)).stringWidth(CLASS_OPTIONS[i]);
                    int optionX = (getWidth() - optionWidth) / 2;
                    Rectangle optionRect = new Rectangle(optionX - 20, optionY - 32, optionWidth + 40, optionHeight);
                    if (optionRect.contains(e.getPoint())) {
                        classSelectedIndex = i;
                        repaint();
                        select_current_option();
                        return;
                    }
                }
                // Detect click on Back button
                if (backButtonBounds.contains(e.getPoint())) {
                    classSelectedIndex = BACK_OPTION_INDEX;
                    repaint();
                    select_current_option();
                    return;
                }
            }
        }
        super.processMouseEvent(e);
    }

    @Override
    public void setVisible(boolean aFlag) {
        super.setVisible(aFlag);
        enableEvents(java.awt.AWTEvent.MOUSE_EVENT_MASK);
    }

    public void go_back() {
        if (mode == Mode.CLASS_SELECTION) {
            mode = Mode.MAIN_MENU;
            repaint();
        }
        // If already at MAIN_MENU, do nothing (or could trigger app exit if desired)
    }
} 