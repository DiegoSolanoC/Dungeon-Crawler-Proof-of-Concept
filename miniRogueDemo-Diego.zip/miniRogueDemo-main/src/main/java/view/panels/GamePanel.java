package view.panels;

import view.GameView;
import model.map.Map;
import model.characters.Player;
import utilities.Position;
import enums.GameConstants;
import enums.TileType;
import javax.swing.*;
import java.awt.*;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
* Panel that displays the game world, player, enemies, and items.
* Renders the 2D pixel art game environment.
*/
public class GamePanel extends JPanel {

private GameView parentView;
private Map currentMap;
private Player player;
private boolean showPauseOverlay;
private int pauseMenuSelection = 0; // 0 = Resume, 1 = Quit
private Rectangle resumeButtonBounds = new Rectangle();
private Rectangle quitButtonBounds = new Rectangle();
private boolean debugMode = false;
private Timer repaintTimer;
// Remove debugPrintTimer and printTilesAroundPlayer

/**
    * MANDATORY: Constructor for GamePanel
    * 
    * @param parentView The parent GameView
*/
public GamePanel(GameView parentView) {
this.parentView = parentView;
this.showPauseOverlay = false;
setBackground(Color.BLACK);
setPreferredSize(new Dimension(
GameConstants.WINDOW_WIDTH,
GameConstants.WINDOW_HEIGHT - GameConstants.UI_PANEL_HEIGHT
));
// Start a timer to repaint at ~60 FPS
repaintTimer = new Timer(16, new ActionListener() {
public void actionPerformed(ActionEvent e) {
if (player != null && currentMap != null) {
player.update_movement(currentMap);
}
repaint();
}
});
repaintTimer.start();
}

/**
    * MANDATORY: Set the current map to display
    * 
    * @param map The Map to render
*/
public void set_map(Map map) {
this.currentMap = map;
repaint();
}

/**
    * MANDATORY: Update display components
*/
public void update_display() {
repaint();
}

/**
    * MANDATORY: Update player position on screen
    * 
    * @param position New player position
*/
public void update_player_position(Position position) {
repaint();
}

/**
    * MANDATORY: Update player stats display
*/
public void update_player_stats() {
repaint();
}

/**
    * MANDATORY: Show pause overlay
*/
public void show_pause_overlay() {
showPauseOverlay = true;
repaint();
}

/**
    * MANDATORY: Custom painting method
    * 
    * @param g Graphics context
*/
@Override
protected void paintComponent(Graphics g) {
super.paintComponent(g);
Graphics2D g2d = (Graphics2D) g;

if (currentMap != null) {
render_map(g2d);
render_entities(g2d);
}

render_ui(g2d);

if (showPauseOverlay) {
render_pause_overlay(g2d);
}
}

/**
    * MANDATORY: Render the map tiles
    * 
    * @param g2d Graphics2D context
*/
private void render_map(Graphics2D g2d) {
int tileSize = GameConstants.TILE_SIZE;

for (int x = 0; x < currentMap.get_width(); x++) {
for (int y = 0; y < currentMap.get_height(); y++) {
utilities.Tile tile = currentMap.get_tile(x, y);
if (tile != null && (debugMode || tile.is_explored())) {
render_tile(g2d, tile, x * tileSize, y * tileSize);
}
}
}
}

/**
    * MANDATORY: Render individual tile
    * 
    * @param g2d Graphics2D context
    * @param tile Tile to render
    * @param screenX X coordinate on screen
    * @param screenY Y coordinate on screen
*/
private void render_tile(Graphics2D g2d, utilities.Tile tile, int screenX, int screenY) {
int tileSize = GameConstants.TILE_SIZE;

switch (tile.get_tile_type()) {
case WALL:
g2d.setColor(Color.GRAY);
break;
case FLOOR:
g2d.setColor(Color.LIGHT_GRAY);
break;
case ENTRANCE:
g2d.setColor(Color.GREEN);
break;
case BOSS_ROOM:
g2d.setColor(Color.RED);
break;
default:
g2d.setColor(Color.DARK_GRAY);
}

g2d.fillRect(screenX, screenY, tileSize, tileSize);

// Draw tile border
g2d.setColor(Color.BLACK);
g2d.drawRect(screenX, screenY, tileSize, tileSize);

// Draw items
if (tile.has_items()) {
g2d.setColor(Color.YELLOW);
g2d.fillOval(screenX + 4, screenY + 4, tileSize - 8, tileSize - 8);
}
}

/**
    * MANDATORY: Render characters and entities
    * 
    * @param g2d Graphics2D context
*/
private void render_entities(Graphics2D g2d) {
    int tileSize = GameConstants.TILE_SIZE;
    // Render enemies
    if (currentMap != null && parentView != null && parentView.get_controller() != null) {
        // Try to get all enemies from the game logic
        java.util.List<model.characters.Enemy> enemies = null;
        try {
            enemies = ((model.gameLogic.GameLogic)parentView.get_controller().get_model()).get_current_enemies();
        } catch (Exception e) {}
        if (enemies != null) {
            for (model.characters.Enemy enemy : enemies) {
                int ex = (int)(enemy.getPixelX() / tileSize);
                int ey = (int)(enemy.getPixelY() / tileSize);
                if (debugMode || (ex >= 0 && ey >= 0 && ex < currentMap.get_width() && ey < currentMap.get_height() && currentMap.get_tile(ex, ey).is_explored())) {
                    g2d.setColor(Color.RED);
                    g2d.fillOval((int)enemy.getPixelX() + 4, (int)enemy.getPixelY() + 4, tileSize - 8, tileSize - 8);
                    // Draw chase path in debug mode
                    if (debugMode) {
                        java.util.List<int[]> path = enemy.getChasePath();
                        g2d.setColor(Color.MAGENTA);
                        for (int[] step : path) {
                            g2d.drawRect(step[0] * tileSize + tileSize/4, step[1] * tileSize + tileSize/4, tileSize/2, tileSize/2);
                        }
                    }
                }
            }
        }
    }
    // Render player
    if (player != null) {
        g2d.setColor(Color.BLUE);
        g2d.fillOval(
            (int)player.getPixelX() + 2,
            (int)player.getPixelY() + 2,
            tileSize - 4,
            tileSize - 4
        );
    }
}

/**
    * MANDATORY: Render UI elements
    * 
    * @param g2d Graphics2D context
*/
private void render_ui(Graphics2D g2d) {
if (player != null) {
g2d.setColor(Color.WHITE);
g2d.setFont(new Font("Arial", Font.BOLD, 14));

     int y = getHeight() - 20;
     g2d.drawString("HP: " + player.get_current_hp() + "/" + player.get_max_hp(), 10, y);
     g2d.drawString("MP: " + player.get_current_mp() + "/" + player.get_max_mp(), 150, y);
     g2d.drawString("Level: " + player.get_level(), 290, y);
     g2d.drawString("Class: " + player.get_character_class().get_class_name(), 400, y);
    }

// Controls help
g2d.setColor(Color.LIGHT_GRAY);
g2d.setFont(new Font("Arial", Font.PLAIN, 10));
g2d.drawString("WASD/Arrows: Move | Space: Attack | I: Inventory | ESC: Pause", 10, getHeight() - 5);
}

/**
    * MANDATORY: Render pause overlay
    * 
    * @param g2d Graphics2D context
*/
private void render_pause_overlay(Graphics2D g2d) {
    // Semi-transparent overlay
    g2d.setColor(new Color(0, 0, 0, 128));
    g2d.fillRect(0, 0, getWidth(), getHeight());

    // Popup background with drop shadow
    int boxWidth = 400;
    int boxHeight = 220;
    int boxX = (getWidth() - boxWidth) / 2;
    int boxY = (getHeight() - boxHeight) / 2;
    g2d.setColor(new Color(0, 0, 0, 180));
    g2d.fillRoundRect(boxX + 6, boxY + 6, boxWidth, boxHeight, 30, 30); // shadow
    g2d.setColor(new Color(40, 40, 40, 230));
    g2d.fillRoundRect(boxX, boxY, boxWidth, boxHeight, 30, 30);
    g2d.setColor(Color.WHITE);
    g2d.setStroke(new BasicStroke(3));
    g2d.drawRoundRect(boxX, boxY, boxWidth, boxHeight, 30, 30);

    // Pause text
    g2d.setFont(new Font("Arial", Font.BOLD, 40));
    FontMetrics fm = g2d.getFontMetrics();
    String pauseText = "Game Paused";
    int textX = boxX + (boxWidth - fm.stringWidth(pauseText)) / 2;
    int textY = boxY + 60;
    g2d.drawString(pauseText, textX, textY);

    // Menu options
    g2d.setFont(new Font("Arial", Font.PLAIN, 24));
    fm = g2d.getFontMetrics();
    String resumeText = "Resume";
    String quitText = "Quit to Main Menu";
    int resumeX = boxX + (boxWidth - fm.stringWidth(resumeText)) / 2;
    int resumeY = textY + 50;
    int quitX = boxX + (boxWidth - fm.stringWidth(quitText)) / 2;
    int quitY = resumeY + 40;
    resumeButtonBounds.setBounds(resumeX - 20, resumeY - 28, fm.stringWidth(resumeText) + 40, 36);
    quitButtonBounds.setBounds(quitX - 20, quitY - 28, fm.stringWidth(quitText) + 40, 36);
    // Highlight selection
    if (pauseMenuSelection == 0) {
        g2d.setColor(Color.YELLOW);
        g2d.drawRect(resumeX - 20, resumeY - 28, fm.stringWidth(resumeText) + 40, 36);
    } else {
        g2d.setColor(Color.LIGHT_GRAY);
    }
    g2d.drawString(resumeText, resumeX, resumeY);
    if (pauseMenuSelection == 1) {
        g2d.setColor(Color.YELLOW);
        g2d.drawRect(quitX - 20, quitY - 28, fm.stringWidth(quitText) + 40, 36);
    } else {
        g2d.setColor(Color.LIGHT_GRAY);
    }
    g2d.drawString(quitText, quitX, quitY);
}

/**
    * MANDATORY: Set player reference for rendering
    * 
    * @param player The Player instance
*/
public void set_player(Player player) {
this.player = player;
}

public void set_debug_mode(boolean debugMode) {
    this.debugMode = debugMode;
    repaint();
}
public boolean is_debug_mode() {
    return debugMode;
}

// Handle pause menu navigation and selection
public boolean handlePauseMenuInput(int keyCode) {
    if (!showPauseOverlay) return false;
    if (keyCode == java.awt.event.KeyEvent.VK_UP || keyCode == java.awt.event.KeyEvent.VK_W) {
        pauseMenuSelection = (pauseMenuSelection - 1 + 2) % 2;
        repaint();
        return true;
    } else if (keyCode == java.awt.event.KeyEvent.VK_DOWN || keyCode == java.awt.event.KeyEvent.VK_S) {
        pauseMenuSelection = (pauseMenuSelection + 1) % 2;
        repaint();
        return true;
    } else if (keyCode == java.awt.event.KeyEvent.VK_ENTER || keyCode == java.awt.event.KeyEvent.VK_ESCAPE) {
        if (pauseMenuSelection == 0 || keyCode == java.awt.event.KeyEvent.VK_ESCAPE) {
            showPauseOverlay = false;
            parentView.get_controller().handle_input("RESUME_GAME");
        } else if (pauseMenuSelection == 1) {
            showPauseOverlay = false;
            parentView.get_controller().handle_input("BACK_TO_MENU");
        }
        pauseMenuSelection = 0;
        repaint();
        return true;
    }
    return false;
}

@Override
protected void processMouseEvent(java.awt.event.MouseEvent e) {
    if (showPauseOverlay && e.getID() == java.awt.event.MouseEvent.MOUSE_CLICKED) {
        if (resumeButtonBounds.contains(e.getPoint())) {
            pauseMenuSelection = 0;
            showPauseOverlay = false;
            repaint();
            parentView.get_controller().handle_input("RESUME_GAME");
            return;
        } else if (quitButtonBounds.contains(e.getPoint())) {
            pauseMenuSelection = 1;
            showPauseOverlay = false;
            repaint();
            parentView.get_controller().handle_input("BACK_TO_MENU");
            return;
        }
    }
    super.processMouseEvent(e);
}

@Override
public void setVisible(boolean aFlag) {
    super.setVisible(aFlag);
    enableEvents(java.awt.AWTEvent.MOUSE_EVENT_MASK);
}
} 