package view.panels;

import view.GameView;
import javax.swing.*;

public class BattlePanel extends JPanel {
    public BattlePanel(GameView parentView) {
        // Stub constructor
    }
    public void update_display() {}
    public void start_battle(Object data) {}
} 