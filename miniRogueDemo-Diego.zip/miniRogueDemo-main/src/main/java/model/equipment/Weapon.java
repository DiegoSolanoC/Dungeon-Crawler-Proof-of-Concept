package model.equipment;

import enums.CharacterClass;

/**
 * Weapon equipment that increases character attack power.
 * Can also provide MP bonuses for magical weapons.
 */
public class Weapon extends Equipment {
    private int mpPower; // Additional MP provided by weapon

    /**
     * MANDATORY: Constructor for Weapon
     *
     * @param name Weapon name
     * @param description Weapon description
     * @param atkPower Attack power bonus
     * @param mpPower MP power bonus
     * @param classType Required character class
     */
    public Weapon(String name, String description, int atkPower, int mpPower, CharacterClass classType) {
        super(name, description, atkPower, classType);
        this.mpPower = mpPower;
    }

    /**
     * MANDATORY: Get weapon attack power
     *
     * @return Current attack power including upgrades
     */
    public int get_attack_power() {
        return potency; // Potency represents attack power for weapons
    }

    /**
     * MANDATORY: Get weapon MP power
     *
     * @return Current MP power including upgrades
     */
    public int get_mp_power() {
        // MP power also scales with upgrades
        double upgradeMultiplier = 1.0 + (upgradeLevel * 0.2);
        return (int)(mpPower * upgradeMultiplier);
    }

    /**
     * MANDATORY: Get weapon statistics summary
     *
     * @return Formatted stats string
     */
    @Override
    public String get_stats() {
        StringBuilder stats = new StringBuilder();
        stats.append("ATK: ").append(get_attack_power());
        if (get_mp_power() > 0) {
            stats.append(", MP: ").append(get_mp_power());
        }
        return stats.toString();
    }

    @Override
    public String toString() {
        return super.toString() + " [" + get_stats() + "]";
    }
} 