package model.equipment;

import enums.CharacterClass;
import enums.GameConstants;
import model.items.Item;
import model.characters.Character;

/**
 * Abstract base class for all equipment items (weapons and armor).
 * Provides upgrade functionality and stat management.
 */
public abstract class Equipment extends Item {
    // MANDATORY: Equipment attributes
    protected int upgradeLevel;
    protected int baseStatValue;

    /**
     * MANDATORY: Constructor for Equipment
     *
     * @param name Equipment name
     * @param description Equipment description
     * @param potency Base stat value
     * @param classType Character class requirement
     */
    public Equipment(String name, String description, int potency, CharacterClass classType) {
        super(name, description, potency, classType);
        this.upgradeLevel = 0;
        this.baseStatValue = potency;
    }

    /**
     * MANDATORY: Equipment cannot be directly "used" like consumables
     *
     * @param character The character (ignored)
     * @return false - equipment must be equipped, not used
     */
    @Override
    public boolean use(Character character) {
        return false; // Equipment is equipped, not used
    }

    /**
     * MANDATORY: Upgrade equipment using key items
     *
     * @return true if upgrade was successful
     */
    public boolean upgrade() {
        if (upgradeLevel >= GameConstants.MAX_EQUIPMENT_LEVEL) {
            return false; // Already at maximum upgrade level
        }
        upgradeLevel++;
        apply_upgrade_bonus();
        return true;
    }

    /**
     * MANDATORY: Apply stat bonuses based on upgrade level
     */
    protected void apply_upgrade_bonus() {
        // Each upgrade level increases stats by 20% of base value
        double upgradeMultiplier = 1.0 + (upgradeLevel * 0.2);
        potency = (int)(baseStatValue * upgradeMultiplier);
    }

    /**
     * MANDATORY: Get current equipment statistics
     *
     * @return Equipment stats as formatted string
     */
    public abstract String get_stats();

    /**
     * MANDATORY: Check if equipment can be upgraded further
     *
     * @return true if upgrade is possible
     */
    public boolean can_upgrade() {
        return upgradeLevel < GameConstants.MAX_EQUIPMENT_LEVEL;
    }

    // MANDATORY: Getters
    public int get_upgrade_level() { return upgradeLevel; }
    public int get_base_stat_value() { return baseStatValue; }

    @Override
    public String toString() {
        String upgradeInfo = (upgradeLevel > 0) ? " (+" + upgradeLevel + ")" : "";
        return super.toString() + upgradeInfo;
    }
} 