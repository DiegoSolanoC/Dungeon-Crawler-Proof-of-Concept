package model.equipment;

import enums.CharacterClass;

/**
 * Armor equipment that provides defense against attacks.
 * Can provide both physical and magical defense.
 */
public class Armor extends Equipment {
    private int atkDefense; // Physical defense value
    private int mpDefense;  // Magical defense value

    /**
     * MANDATORY: Constructor for Armor
     *
     * @param name Armor name
     * @param description Armor description
     * @param potency Total defense value
     * @param atkDefense Physical defense value
     * @param mpDefense Magical defense value
     * @param classType Required character class
     */
    public Armor(String name, String description, int potency, int atkDefense, int mpDefense, CharacterClass classType) {
        super(name, description, potency, classType);
        this.atkDefense = atkDefense;
        this.mpDefense = mpDefense;
    }

    /**
     * MANDATORY: Get total defense value (primary stat)
     *
     * @return Current defense value including upgrades
     */
    public int get_defense_value() {
        return potency; // Potency represents total defense for armor
    }

    /**
     * MANDATORY: Get physical attack defense
     *
     * @return Current attack defense including upgrades
     */
    public int get_atk_defense() {
        double upgradeMultiplier = 1.0 + (upgradeLevel * 0.2);
        return (int)(atkDefense * upgradeMultiplier);
    }

    /**
     * MANDATORY: Get magical attack defense
     *
     * @return Current MP defense including upgrades
     */
    public int get_mp_defense() {
        double upgradeMultiplier = 1.0 + (upgradeLevel * 0.2);
        return (int)(mpDefense * upgradeMultiplier);
    }

    /**
     * MANDATORY: Get armor statistics summary
     *
     * @return Formatted stats string
     */
    @Override
    public String get_stats() {
        StringBuilder stats = new StringBuilder();
        stats.append("DEF: ").append(get_defense_value());
        if (get_atk_defense() > 0) {
            stats.append(", ATK DEF: ").append(get_atk_defense());
        }
        if (get_mp_defense() > 0) {
            stats.append(", MP DEF: ").append(get_mp_defense());
        }
        return stats.toString();
    }

    @Override
    public String toString() {
        return super.toString() + " [" + get_stats() + "]";
    }
} 