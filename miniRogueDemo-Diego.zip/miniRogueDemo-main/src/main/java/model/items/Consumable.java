package model.items;

import enums.CharacterClass;
import model.characters.Character;

/**
 * Consumable items that provide immediate effects when used.
 * Items are consumed upon use and removed from inventory.
 */
public class Consumable extends Item {
    private String effectType; // "health", "mana", "experience"

    /**
     * MANDATORY: Constructor for Consumable
     *
     * @param name Item name
     * @param description Item description
     * @param potency Effect strength
     * @param effectType Type of effect ("health", "mana", "experience")
     */
    public Consumable(String name, String description, int potency, String effectType) {
        super(name, description, potency);
        this.effectType = effectType;
    }

    /**
     * MANDATORY: Use consumable on character
     *
     * @param character The character to apply effects to
     * @return true if item was consumed
     */
    @Override
    public boolean use(Character character) {
        if (character == null || !character.is_alive()) {
            return false;
        }
        switch (effectType.toLowerCase()) {
            case "health":
                character.heal(potency);
                return true;
            case "mana":
                character.restore_mp(potency);
                return true;
            case "experience":
                if (character instanceof model.characters.Player) {
                    ((model.characters.Player) character).gain_experience(potency);
                    return true;
                }
                break;
            default:
                return false;
        }
        return false;
    }

    public String get_effect_type() {
        return effectType;
    }

    @Override
    public String toString() {
        return super.toString() + " (+" + potency + " " + effectType + ")";
    }
} 