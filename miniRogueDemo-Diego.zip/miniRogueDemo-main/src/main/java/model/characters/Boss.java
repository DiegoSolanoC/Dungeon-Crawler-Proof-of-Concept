package model.characters;

import enums.CharacterClass;
import utilities.Position;
import model.items.Item;
import model.items.Consumable;
import model.items.KeyItem;
import model.equipment.Weapon;
import model.equipment.Armor;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Boss character class extending Enemy.
 * Represents powerful floor-ending enemies with special abilities and enhanced rewards.
 */
public class Boss extends Enemy {

    // MANDATORY: Boss-specific attributes
    private List<String> specialAbilities;
    private int abilityPhaseThreshold;
    private boolean inSpecialPhase;
    private int originalMaxHp;

    /**
     * MANDATORY: Constructor for Boss
     *
     * @param name Boss name
     * @param characterClass Boss combat class
     * @param position Initial spawn position
     */
    public Boss(String name, CharacterClass characterClass, Position position) {
        super(name, characterClass, position, "boss");
        this.specialAbilities = new ArrayList<>();
        this.inSpecialPhase = false;
        this.abilityPhaseThreshold = (int)(maxHp * 0.5); // Activate at 50% HP
        this.originalMaxHp = maxHp;
        // Enhance boss statistics
        enhance_boss_stats();
        initialize_boss_equipment();
        initialize_special_abilities();
        enhance_loot_table();
    }

    /**
     * MANDATORY: Enhance boss statistics for increased challenge
     */
    private void enhance_boss_stats() {
        // Bosses are significantly stronger than regular enemies
        this.maxHp = (int)(maxHp * 3.0); // 3x health
        this.currentHp = maxHp;
        this.baseAtk = (int)(baseAtk * 2.0); // 2x attack
        this.maxMp = (int)(maxMp * 2.5); // 2.5x mana
        this.currentMp = maxMp;
        // Update experience value for enhanced stats
        this.experienceValue = calculate_boss_experience();
    }

    /**
     * MANDATORY: Initialize boss-tier equipment
     */
    private void initialize_boss_equipment() {
        switch (characterClass) {
            case WARRIOR:
                this.equippedWeapon = new Weapon("Legendary Blade", "A weapon of immense power", 35, 0, characterClass);
                this.equippedArmor = new Armor("Plate Armor", "Masterwork protective gear", 0, 15, 3, characterClass);
                break;
            case MAGE:
                this.equippedWeapon = new Weapon("Staff of Power", "Channels devastating magic", 20, 30, characterClass);
                this.equippedArmor = new Armor("Arcane Robes", "Robes woven with protective spells", 0, 8, 20, characterClass);
                break;
            case ROGUE:
                this.equippedWeapon = new Weapon("Shadow Fang", "Blade that drinks light itself", 28, 15, characterClass);
                this.equippedArmor = new Armor("Assassin's Garb", "Armor that bends shadow", 0, 10, 8, characterClass);
                break;
        }
    }

    /**
     * MANDATORY: Initialize boss special abilities
     */
    private void initialize_special_abilities() {
        switch (characterClass) {
            case WARRIOR:
                specialAbilities.add("BERSERKER_RAGE");
                specialAbilities.add("WHIRLWIND_ATTACK");
                specialAbilities.add("DEFENSIVE_STANCE");
                break;
            case MAGE:
                specialAbilities.add("METEOR_STORM");
                specialAbilities.add("MANA_DRAIN");
                specialAbilities.add("TELEPORT_STRIKE");
                break;
            case ROGUE:
                specialAbilities.add("SHADOW_CLONE");
                specialAbilities.add("POISON_CLOUD");
                specialAbilities.add("VANISH");
                break;
        }
    }

    /**
     * MANDATORY: Enhance loot table with boss rewards
     */
    private void enhance_loot_table() {
        // Clear basic loot and add boss-tier rewards
        lootTable.clear();
        // High-tier consumables
        lootTable.add(new Consumable("Greater Health Potion", "Restores 100 HP", 100, "health"));
        lootTable.add(new Consumable("Greater Mana Potion", "Restores 75 MP", 75, "mana"));
        // Boss-tier equipment (guaranteed drops)
        switch (characterClass) {
            case WARRIOR:
                lootTable.add(new Weapon("Champion's Sword", "Blade of a fallen hero", 30, 0, characterClass));
                lootTable.add(new Armor("Knight's Plate", "Armor blessed by light", 0, 12, 5, characterClass));
                break;
            case MAGE:
                lootTable.add(new Weapon("Arcane Wand", "Wand of pure magical energy", 12, 20, characterClass));
                lootTable.add(new Armor("Mystic Robes", "Robes imbued with protective magic", 0, 6, 15, characterClass));
                break;
            case ROGUE:
                lootTable.add(new Weapon("Assassin's Blade", "Blade forged in shadow", 25, 10, characterClass));
                lootTable.add(new Armor("Shadow Mail", "Armor that bends with darkness", 0, 8, 12, characterClass));
                break;
        }
        // Special upgrade materials
        lootTable.add(new KeyItem("Upgrade Crystal", "Crystal used for equipment enhancement", characterClass.get_class_name()));
        lootTable.add(new Consumable("Boss Elixir", "Powerful restoration potion", 150, "health"));
    }

    /**
     * MANDATORY: Calculate boss experience value
     *
     * @return Experience points for defeating this boss
     */
    private int calculate_boss_experience() {
        return experienceValue * 5; // Bosses give 5x normal experience
    }

    /**
     * MANDATORY: Use special ability based on current HP
     */
    public void use_special_ability() {
        if (currentHp <= abilityPhaseThreshold && !inSpecialPhase) {
            inSpecialPhase = true;
            notify_observers("BOSS_PHASE_CHANGE", "Special abilities activated");
        }
        if (inSpecialPhase && !specialAbilities.isEmpty()) {
            String ability = specialAbilities.get(new Random().nextInt(specialAbilities.size()));
            execute_special_ability(ability);
        }
    }

    /**
     * MANDATORY: Execute specific special ability
     *
     * @param ability The special ability to execute
     */
    private void execute_special_ability(String ability) {
        switch (ability) {
            case "BERSERKER_RAGE":
                // Increase attack power temporarily
                baseAtk = (int)(baseAtk * 1.5);
                notify_observers("BOSS_ABILITY", "Berserker Rage activated - ATK increased!");
                break;
            case "WHIRLWIND_ATTACK":
                // Area attack ability
                notify_observers("BOSS_ABILITY", "Whirlwind Attack - Area damage incoming!");
                break;
            case "DEFENSIVE_STANCE":
                // Reduce incoming damage
                notify_observers("BOSS_ABILITY", "Defensive Stance - Damage reduction active!");
                break;
            case "METEOR_STORM":
                // High magic damage
                if (use_mp(20)) {
                    notify_observers("BOSS_ABILITY", "Meteor Storm - Massive magic damage!");
                }
                break;
            case "MANA_DRAIN":
                // Drain player MP
                notify_observers("BOSS_ABILITY", "Mana Drain - Player MP reduced!");
                break;
            case "TELEPORT_STRIKE":
                // Instant teleport attack
                if (use_mp(15)) {
                    notify_observers("BOSS_ABILITY", "Teleport Strike - Instant attack!");
                }
                break;
            case "SHADOW_CLONE":
                // Create temporary duplicates
                notify_observers("BOSS_ABILITY", "Shadow Clone - Duplicates created!");
                break;
            case "POISON_CLOUD":
                // Area poison effect
                notify_observers("BOSS_ABILITY", "Poison Cloud - Toxic damage over time!");
                break;
            case "VANISH":
                // Temporary invisibility
                notify_observers("BOSS_ABILITY", "Vanish - Boss becomes harder to hit!");
                break;
        }
    }

    /**
     * MANDATORY: Override perform_turn for boss AI
     */
    @Override
    public void perform_turn() {
        if (is_alive()) {
            if (new Random().nextInt(100) < 40) { // 40% chance for special ability
                use_special_ability();
            } else {
                perform_ai();
            }
        }
    }

    /**
     * MANDATORY: Check if boss is defeated
     *
     * @return true if boss HP is 0 or below
     */
    public boolean is_defeated() {
        return currentHp <= 0;
    }

    // MANDATORY: Additional getters
    public List<String> get_special_abilities() {
        return new ArrayList<>(specialAbilities);
    }

    public boolean is_in_special_phase() {
        return inSpecialPhase;
    }

    public int get_ability_phase_threshold() {
        return abilityPhaseThreshold;
    }
} 