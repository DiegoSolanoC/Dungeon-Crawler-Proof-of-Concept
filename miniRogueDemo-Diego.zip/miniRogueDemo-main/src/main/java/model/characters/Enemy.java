package model.characters;

import enums.CharacterClass;
import utilities.Position;
import model.items.Item;
import model.items.Consumable;
import model.equipment.Weapon;
import model.equipment.Armor;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import model.map.Map;
import model.characters.Player;
import java.util.Queue;
import java.util.LinkedList;
import java.util.HashSet;
import utilities.Collision;

/**
 * Enemy character class extending Character.
 * Handles AI behavior, loot drops, and combat patterns for dungeon enemies.
 */
public class Enemy extends Character {

    // MANDATORY: Enemy-specific attributes
    private String aiPattern;
    private List<String> weaknesses;
    protected List<Item> lootTable;
    protected int experienceValue;
    private Random random;
    private int aggroRange;
    private boolean isAggressive;
    private transient Thread movementThread;
    private volatile boolean running = false;
    private float pixelX, pixelY;
    private int targetTileX, targetTileY;
    private static final float MOVE_SPEED = 2.5f; // pixels per update (adjust for smoothness)
    private Map map;
    private Player player;
    private boolean chasingPlayer = false;
    private long chaseEndTime = 0;
    private List<int[]> chasePath = new ArrayList<>();
    private int lastPlayerX = -1, lastPlayerY = -1;

    /**
     * MANDATORY: Constructor for Enemy
     *
     * @param name Enemy's name
     * @param characterClass Enemy's combat class
     * @param position Initial spawn position
     * @param aiPattern AI behavior pattern
     */
    public Enemy(String name, CharacterClass characterClass, Position position, String aiPattern) {
        super(name, characterClass, position);
        this.aiPattern = aiPattern;
        this.weaknesses = new ArrayList<>();
        this.lootTable = new ArrayList<>();
        this.random = new Random();
        this.aggroRange = 3;
        this.isAggressive = true;
        // Scale enemy stats based on difficulty
        scale_enemy_stats();
        initialize_enemy_equipment();
        initialize_loot_table();
        initialize_weaknesses();
        // Calculate experience value
        this.experienceValue = calculate_experience_value();
        this.pixelX = position.get_x() * enums.GameConstants.TILE_SIZE;
        this.pixelY = position.get_y() * enums.GameConstants.TILE_SIZE;
        this.targetTileX = position.get_x();
        this.targetTileY = position.get_y();
        startMovementThread();
    }

    private void startMovementThread() {
        running = true;
        movementThread = new Thread(() -> {
            while (running) {
                try {
                    update_movement();
                    Thread.sleep(100); // 100ms per update, adjust for smoothness
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        movementThread.setDaemon(true);
        movementThread.start();
    }

    public void stopMovementThread() {
        running = false;
        if (movementThread != null) {
            movementThread.interrupt();
        }
    }

    // Returns the full path (list of [x, y]) from enemy to player using BFS, or null if no path
    private List<int[]> getPathToPlayer() {
        if (map == null || player == null) return null;
        int width = map.get_width();
        int height = map.get_height();
        boolean[][] visited = new boolean[width][height];
        Queue<int[]> queue = new LinkedList<>();
        int[][] prev = new int[width * height][2];
        for (int i = 0; i < prev.length; i++) prev[i][0] = prev[i][1] = -1;
        int startX = targetTileX;
        int startY = targetTileY;
        int goalX = player.get_position().get_x();
        int goalY = player.get_position().get_y();
        queue.add(new int[]{startX, startY});
        visited[startX][startY] = true;
        int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1}};
        boolean found = false;
        while (!queue.isEmpty()) {
            int[] curr = queue.poll();
            int cx = curr[0], cy = curr[1];
            if (cx == goalX && cy == goalY) {
                found = true;
                break;
            }
            for (int[] dir : dirs) {
                int nx = cx + dir[0];
                int ny = cy + dir[1];
                if (nx >= 0 && ny >= 0 && nx < width && ny < height && !visited[nx][ny]) {
                    if (utilities.Collision.isWalkable(map, nx, ny)) {
                        queue.add(new int[]{nx, ny});
                        visited[nx][ny] = true;
                        prev[nx + ny * width][0] = cx;
                        prev[nx + ny * width][1] = cy;
                    }
                }
            }
        }
        if (!found) return null;
        // Backtrack from goal to start to build the path
        List<int[]> path = new ArrayList<>();
        int cx = goalX, cy = goalY;
        while (!(cx == startX && cy == startY)) {
            path.add(0, new int[]{cx, cy});
            int px = prev[cx + cy * width][0];
            int py = prev[cx + cy * width][1];
            cx = px; cy = py;
            if (cx == -1 || cy == -1) return null;
        }
        return path;
    }

    // Called by the movement thread; will be implemented in next step
    private void update_movement() {
        // Check if we should chase the player
        int playerX = player != null ? player.get_position().get_x() : -1;
        int playerY = player != null ? player.get_position().get_y() : -1;
        if (player != null && position.manhattan_distance_to(player.get_position()) <= aggroRange) {
            chasingPlayer = true;
            chaseEndTime = System.currentTimeMillis() + 5000; // chase for 5 seconds
        }
        if (chasingPlayer) {
            // If chase time expired, stop chasing
            if (System.currentTimeMillis() > chaseEndTime) {
                chasingPlayer = false;
                chasePath.clear();
            } else {
                // Recalculate path if player moved or path is empty
                if (chasePath.isEmpty() || playerX != lastPlayerX || playerY != lastPlayerY) {
                    List<int[]> path = getPathToPlayer();
                    if (path != null && !path.isEmpty()) {
                        chasePath = path;
                        lastPlayerX = playerX;
                        lastPlayerY = playerY;
                    } else {
                        // No path to player, stop chasing
                        chasingPlayer = false;
                        chasePath.clear();
                    }
                }
                // Follow the path step by step
                if (!chasePath.isEmpty() && Math.abs(pixelX - targetTileX * enums.GameConstants.TILE_SIZE) < 0.01f && Math.abs(pixelY - targetTileY * enums.GameConstants.TILE_SIZE) < 0.01f) {
                    int[] next = chasePath.remove(0);
                    if (utilities.Collision.isWalkable(map, next[0], next[1])) {
                        targetTileX = next[0];
                        targetTileY = next[1];
                    } else {
                        // Path blocked, recalculate next update
                        chasePath.clear();
                    }
                }
            }
        }
        // If not chasing, random roam as before
        if (!chasingPlayer) {
            if ((int)(pixelX / enums.GameConstants.TILE_SIZE) == targetTileX &&
                (int)(pixelY / enums.GameConstants.TILE_SIZE) == targetTileY) {
                int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1}};
                for (int attempt = 0; attempt < dirs.length; attempt++) {
                    int[] dir = dirs[random.nextInt(dirs.length)];
                    int nextX = targetTileX + dir[0];
                    int nextY = targetTileY + dir[1];
                    if (utilities.Collision.isWalkable(map, nextX, nextY)) {
                        targetTileX = nextX;
                        targetTileY = nextY;
                        break;
                    }
                }
            }
        }
        // Move pixelX/pixelY toward target tile
        float targetPixelX = targetTileX * enums.GameConstants.TILE_SIZE;
        float targetPixelY = targetTileY * enums.GameConstants.TILE_SIZE;
        float dx = targetPixelX - pixelX;
        float dy = targetPixelY - pixelY;
        float dist = (float)Math.sqrt(dx*dx + dy*dy);
        if (dist > MOVE_SPEED) {
            pixelX += MOVE_SPEED * dx / dist;
            pixelY += MOVE_SPEED * dy / dist;
        } else {
            pixelX = targetPixelX;
            pixelY = targetPixelY;
            this.position = new utilities.Position(targetTileX, targetTileY);
        }
    }

    /**
     * MANDATORY: Scale enemy statistics for challenge balance
     */
    private void scale_enemy_stats() {
        // Enemies have slightly higher HP but lower attack than player equivalents
        this.maxHp = (int)(maxHp * 1.2);
        this.currentHp = maxHp;
        this.baseAtk = (int)(baseAtk * 0.8);
        this.maxMp = (int)(maxMp * 0.9);
        this.currentMp = maxMp;
    }

    /**
     * MANDATORY: Initialize enemy equipment based on class
     */
    private void initialize_enemy_equipment() {
        switch (characterClass) {
            case WARRIOR:
                this.equippedWeapon = new Weapon("Rusty Sword", "An old, worn blade", 10, 0, characterClass);
                this.equippedArmor = new Armor("Chain Mail", "Heavy protective armor", 0, 6, 1, characterClass);
                break;
            case MAGE:
                this.equippedWeapon = new Weapon("Dark Staff", "A staff crackling with energy", 6, 8, characterClass);
                this.equippedArmor = new Armor("Dark Robes", "Mystical protective garments", 0, 2, 6, characterClass);
                break;
            case ROGUE:
                this.equippedWeapon = new Weapon("Curved Blade", "A wickedly sharp curved sword", 9, 3, characterClass);
                this.equippedArmor = new Armor("Shadow Cloak", "Light armor for stealth", 0, 3, 2, characterClass);
                break;
        }
    }

    /**
     * MANDATORY: Initialize loot drop table
     */
    private void initialize_loot_table() {
        // Common drops
        lootTable.add(new Consumable("Health Potion", "Restores 25 HP", 25, "health"));
        lootTable.add(new Consumable("Mana Potion", "Restores 15 MP", 15, "mana"));
        // Class-specific equipment drops (rare)
        switch (characterClass) {
            case WARRIOR:
                if (random.nextInt(100) < 20) {
                    lootTable.add(new Weapon("Battle Axe", "Heavy two-handed weapon", 20, 0, characterClass));
                }
                break;
            case MAGE:
                if (random.nextInt(100) < 20) {
                    lootTable.add(new Weapon("Crystal Staff", "Staff of pure magical energy", 10, 15, characterClass));
                }
                break;
            case ROGUE:
                if (random.nextInt(100) < 20) {
                    lootTable.add(new Weapon("Shadow Blade", "Blade that strikes from darkness", 15, 8, characterClass));
                }
                break;
        }
    }

    /**
     * MANDATORY: Initialize character class weaknesses
     */
    private void initialize_weaknesses() {
        switch (characterClass) {
            case WARRIOR:
                weaknesses.add("MAGIC");
                weaknesses.add("POISON");
                break;
            case MAGE:
                weaknesses.add("PHYSICAL");
                weaknesses.add("SILENCE");
                break;
            case ROGUE:
                weaknesses.add("AREA_ATTACK");
                weaknesses.add("LIGHT");
                break;
        }
    }

    /**
     * MANDATORY: Calculate experience value based on enemy strength
     *
     * @return Experience points awarded for defeating this enemy
     */
    private int calculate_experience_value() {
        int baseExp = 25;
        int hpBonus = maxHp / 10;
        int atkBonus = baseAtk * 2;
        return baseExp + hpBonus + atkBonus;
    }

    /**
     * MANDATORY: Perform AI behavior based on pattern
     */
    public void perform_ai() {
        switch (aiPattern.toLowerCase()) {
            case "aggressive":
                perform_aggressive_ai();
                break;
            case "defensive":
                perform_defensive_ai();
                break;
            case "magical":
                perform_magical_ai();
                break;
            case "sneaky":
                perform_sneaky_ai();
                break;
            default:
                perform_basic_ai();
        }
    }

    /**
     * MANDATORY: Aggressive AI behavior - always attacks
     */
    private void perform_aggressive_ai() {
        // Aggressive enemies always try to attack if player is in range
        notify_observers("ENEMY_ACTION", "AGGRESSIVE_MOVE");
    }

    /**
     * MANDATORY: Defensive AI behavior - waits and counters
     */
    private void perform_defensive_ai() {
        // Defensive enemies wait for player to approach
        if (currentHp < maxHp * 0.3) {
            // Try to heal when low on health
            if (random.nextInt(100) < 40) {
                heal(10);
                notify_observers("ENEMY_ACTION", "HEAL");
            }
        }
        notify_observers("ENEMY_ACTION", "DEFENSIVE_STANCE");
    }

    /**
     * MANDATORY: Magical AI behavior - uses MP abilities
     */
    private void perform_magical_ai() {
        if (currentMp >= 10 && random.nextInt(100) < 60) {
            // Cast spell
            use_mp(10);
            notify_observers("ENEMY_ACTION", "CAST_SPELL");
        } else {
            notify_observers("ENEMY_ACTION", "MAGICAL_ATTACK");
        }
    }

    /**
     * MANDATORY: Sneaky AI behavior - hit and run tactics
     */
    private void perform_sneaky_ai() {
        if (random.nextInt(100) < 30) {
            notify_observers("ENEMY_ACTION", "SNEAK_ATTACK");
        } else {
            notify_observers("ENEMY_ACTION", "EVASIVE_MOVE");
        }
    }

    /**
     * MANDATORY: Basic AI behavior - random actions
     */
    private void perform_basic_ai() {
        String[] actions = {"ATTACK", "MOVE", "WAIT"};
        String action = actions[random.nextInt(actions.length)];
        notify_observers("ENEMY_ACTION", action);
    }

    /**
     * MANDATORY: Drop loot when defeated
     *
     * @return List of items dropped
     */
    public List<Item> drop_loot() {
        List<Item> droppedItems = new ArrayList<>();
        // Random chance for each item in loot table
        for (Item item : lootTable) {
            if (random.nextInt(100) < 30) { // 30% drop chance
                droppedItems.add(item);
            }
        }
        // Always drop at least one item
        if (droppedItems.isEmpty() && !lootTable.isEmpty()) {
            droppedItems.add(lootTable.get(random.nextInt(lootTable.size())));
        }
        return droppedItems;
    }

    /**
     * MANDATORY: Check if enemy has specific weakness
     *
     * @param weakness The weakness type to check
     * @return true if enemy is weak to this type
     */
    public boolean is_weak_to(String weakness) {
        return weaknesses.contains(weakness.toUpperCase());
    }

    /**
     * MANDATORY: Implement attack behavior for enemy
     *
     * @param target The character to attack
     * @return Damage dealt
     */
    @Override
    public int attack(Character target) {
        int damage = get_total_attack();
        // Apply AI pattern modifiers
        damage = apply_ai_attack_modifier(damage);
        // Small chance to miss
        if (random.nextInt(100) < enums.GameConstants.MISS_CHANCE) {
            damage = 0;
            notify_observers("ATTACK_MISSED", target);
        }
        notify_observers("ENEMY_ATTACKED", target);
        return damage;
    }

    /**
     * MANDATORY: Apply AI-specific attack modifiers
     *
     * @param baseDamage Base damage before modifiers
     * @return Modified damage
     */
    private int apply_ai_attack_modifier(int baseDamage) {
        switch (aiPattern.toLowerCase()) {
            case "aggressive":
                return (int)(baseDamage * 1.1); // 10% damage boost
            case "defensive":
                return (int)(baseDamage * 0.8); // 20% damage reduction
            case "magical":
                if (currentMp >= 5) {
                    use_mp(5);
                    return (int)(baseDamage * 1.3); // Magical damage boost
                }
                break;
            case "sneaky":
                if (random.nextInt(100) < 15) {
                    return baseDamage * 2; // Sneak attack
                }
                break;
        }
        return baseDamage;
    }

    /**
     * MANDATORY: Enemy turn processing with AI
     */
    @Override
    public void perform_turn() {
        if (is_alive()) {
            perform_ai();
        }
    }

    // MANDATORY: Getters
    public String get_ai_pattern() { return aiPattern; }
    public List<String> get_weaknesses() { return new ArrayList<>(weaknesses); }
    public int get_experience_value() { return experienceValue; }
    public int get_aggro_range() { return aggroRange; }
    public boolean is_aggressive() { return isAggressive; }
    public float getPixelX() { return pixelX; }
    public float getPixelY() { return pixelY; }

    public void setMap(Map map) {
        this.map = map;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public List<int[]> getChasePath() {
        return new ArrayList<>(chasePath);
    }
} 