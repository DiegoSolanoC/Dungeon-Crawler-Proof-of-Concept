package model.characters;

import enums.CharacterClass;
import enums.GameConstants;
import utilities.Position;
import model.items.Item;
import model.items.Consumable;
import model.equipment.Weapon;
import model.equipment.Armor;
import model.equipment.Equipment;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import utilities.Collision;
import utilities.Tile;

/**
 * Player character class extending Character.
 * Handles player-specific functionality including inventory, leveling, and class selection.
 */
public class Player extends Character {

    // MANDATORY: Player-specific attributes
    private List<Item> inventory;
    private int inventoryCapacity;
    private String selectedClass;
    private Random random;
    private float pixelX, pixelY;
    private int targetTileX, targetTileY;
    private int moveDX = 0, moveDY = 0;
    private static final float MOVE_SPEED = 3.0f; // pixels per update

    /**
     * MANDATORY: Constructor for Player
     *
     * @param name Player's chosen name
     * @param characterClass Selected character class
     * @param startPosition Initial spawn position
     */
    public Player(String name, CharacterClass characterClass, Position startPosition) {
        super(name, characterClass, startPosition);
        this.inventory = new ArrayList<>();
        this.inventoryCapacity = GameConstants.UNLIMITED_INVENTORY;
        this.selectedClass = characterClass.get_class_name();
        this.random = new Random();
        // Initialize class-specific starting equipment
        initialize_starting_equipment();
        // Initialize smooth movement fields
        this.pixelX = startPosition.get_x() * GameConstants.TILE_SIZE;
        this.pixelY = startPosition.get_y() * GameConstants.TILE_SIZE;
        this.targetTileX = startPosition.get_x();
        this.targetTileY = startPosition.get_y();
    }

    /**
     * MANDATORY: Initialize starting equipment based on character class
     */
    private void initialize_starting_equipment() {
        switch (characterClass) {
            case WARRIOR:
                // Warrior starts with basic sword and leather armor
                this.equippedWeapon = new Weapon("Iron Sword", "A sturdy iron blade", 15, 0, characterClass);
                this.equippedArmor = new Armor("Leather Armor", "Basic protective gear", 0, 5, 2, characterClass);
                break;
            case MAGE:
                // Mage starts with staff and robes
                this.equippedWeapon = new Weapon("Oak Staff", "A magical focusing staff", 8, 10, characterClass);
                this.equippedArmor = new Armor("Cloth Robes", "Light magical robes", 0, 2, 8, characterClass);
                break;
            case ROGUE:
                // Rogue starts with dagger and light armor
                this.equippedWeapon = new Weapon("Steel Dagger", "A sharp, lightweight blade", 12, 5, characterClass);
                this.equippedArmor = new Armor("Studded Leather", "Flexible protective wear", 0, 4, 3, characterClass);
                break;
        }
        // Add starting consumables
        add_starting_items();
    }

    /**
     * MANDATORY: Add starting items to inventory
     */
    private void add_starting_items() {
        // Add health potions
        collect_item(new Consumable("Health Potion", "Restores 50 HP", 50, "health"));
        collect_item(new Consumable("Health Potion", "Restores 50 HP", 50, "health"));
        // Add mana potions for magic users
        if (characterClass == CharacterClass.MAGE || characterClass == CharacterClass.ROGUE) {
            collect_item(new Consumable("Mana Potion", "Restores 30 MP", 30, "mana"));
        }
    }

    /**
     * MANDATORY: Select character class (used during character creation)
     *
     * @param classType The CharacterClass to select
     */
    public void select_class(CharacterClass classType) {
        this.characterClass = classType;
        this.selectedClass = classType.get_class_name();
        initialize_stats();
        initialize_starting_equipment();
        notify_observers("CLASS_SELECTED", classType);
    }

    /**
     * MANDATORY: Collect an item and add to inventory
     *
     * @param item The Item to collect
     * @return true if item was successfully added
     */
    public boolean collect_item(Item item) {
        if (item == null) return false;
        if (inventoryCapacity == GameConstants.UNLIMITED_INVENTORY ||
            inventory.size() < inventoryCapacity) {
            inventory.add(item);
            notify_observers("ITEM_COLLECTED", item);
            return true;
        }
        return false; // Inventory full
    }

    /**
     * MANDATORY: Use an item from inventory
     *
     * @param item The Item to use
     * @return true if item was successfully used
     */
    public boolean use_item(Item item) {
        if (!inventory.contains(item)) return false;
        boolean used = item.use(this);
        if (used) {
            inventory.remove(item);
            notify_observers("ITEM_USED", item);
        }
        return used;
    }

    /**
     * MANDATORY: Open inventory interface
     */
    public void open_inventory() {
        notify_observers("INVENTORY_OPENED", inventory);
    }

    /**
     * MANDATORY: Upgrade equipment using key items
     *
     * @param equipment The Equipment to upgrade
     * @return true if upgrade was successful
     */
    public boolean upgrade_equipment(Equipment equipment) {
        // Find required upgrade items in inventory
        List<Item> upgradeItems = find_upgrade_items_for(equipment);
        if (can_upgrade_equipment(equipment, upgradeItems)) {
            // Remove upgrade items from inventory
            for (Item item : upgradeItems) {
                inventory.remove(item);
            }
            // Perform upgrade
            boolean upgraded = equipment.upgrade();
            if (upgraded) {
                notify_observers("EQUIPMENT_UPGRADED", equipment);
                return true;
            }
        }
        return false;
    }

    /**
     * MANDATORY: Check if equipment can be upgraded
     *
     * @param equipment The Equipment to check
     * @param upgradeItems Available upgrade items
     * @return true if upgrade is possible
     */
    private boolean can_upgrade_equipment(Equipment equipment, List<Item> upgradeItems) {
        return !upgradeItems.isEmpty() &&
            equipment.get_upgrade_level() < GameConstants.MAX_EQUIPMENT_LEVEL;
    }

    /**
     * MANDATORY: Find items that can upgrade specific equipment
     *
     * @param equipment The Equipment to find upgrades for
     * @return List of applicable upgrade items
     */
    private List<Item> find_upgrade_items_for(Equipment equipment) {
        List<Item> upgradeItems = new ArrayList<>();
        for (Item item : inventory) {
            if (item.get_name().contains("Upgrade") &&
                item.get_class_type().equals(equipment.get_class_type().get_class_name())) {
                upgradeItems.add(item);
            }
        }
        return upgradeItems;
    }

    /**
     * MANDATORY: Gain experience and handle leveling
     *
     * @param expGained Amount of experience to gain
     */
    public void gain_experience(int expGained) {
        this.experience += expGained;
        notify_observers("EXPERIENCE_GAINED", expGained);
        // Check for level up
        int requiredExp = Stats.calculate_experience_required(level);
        if (experience >= requiredExp) {
            level_up();
        }
    }

    /**
     * MANDATORY: Handle level up progression
     */
    private void level_up() {
        if (level >= GameConstants.MAX_LEVEL) return;
        level++;
        // Increase stats based on class
        int hpGain = Stats.calculate_hp_per_level(characterClass, level);
        int atkGain = Stats.calculate_atk_per_level(characterClass, level);
        int mpGain = Stats.calculate_mp_per_level(characterClass, level);
        maxHp += hpGain;
        currentHp = maxHp; // Full heal on level up
        baseAtk += atkGain;
        maxMp += mpGain;
        currentMp = maxMp; // Full MP restore on level up
        // Reset experience for next level
        experience = 0;
        notify_observers("LEVEL_UP", level);
    }

    /**
     * MANDATORY: Implement attack behavior for player
     *
     * @param target The character to attack
     * @return Damage dealt
     */
    @Override
    public int attack(Character target) {
        int damage = get_total_attack();
        // Check for critical hit
        int critChance = Stats.calculate_critical_chance(characterClass);
        if (random.nextInt(100) < critChance) {
            damage = (int)(damage * GameConstants.CRITICAL_HIT_MULTIPLIER);
            notify_observers("CRITICAL_HIT", damage);
        }
        // Check for miss
        if (random.nextInt(100) < GameConstants.MISS_CHANCE) {
            damage = 0;
            notify_observers("ATTACK_MISSED", target);
        }
        // Apply class-specific attack modifiers
        damage = apply_class_attack_bonus(damage, target);
        notify_observers("PLAYER_ATTACKED", target);
        return damage;
    }

    /**
     * MANDATORY: Apply class-specific attack bonuses
     *
     * @param baseDamage Base damage before modifiers
     * @param target The target being attacked
     * @return Modified damage
     */
    private int apply_class_attack_bonus(int baseDamage, Character target) {
        switch (characterClass) {
            case WARRIOR:
                // Warriors deal extra damage to armored enemies
                if (target.get_equipped_armor() != null) {
                    return (int)(baseDamage * 1.2);
                }
                break;
            case MAGE:
                // Mages deal bonus magical damage
                if (currentMp >= 5) {
                    use_mp(5);
                    return (int)(baseDamage * 1.3);
                }
                break;
            case ROGUE:
                // Rogues have chance for sneak attack
                if (random.nextInt(100) < 25) {
                    notify_observers("SNEAK_ATTACK", target);
                    return baseDamage * 2;
                }
                break;
        }
        return baseDamage;
    }

    /**
     * MANDATORY: Player turn processing (handled by controller input)
     */
    @Override
    public void perform_turn() {
        // Player turns are handled by user input through controller
        // This method exists to fulfill abstract contract
        notify_observers("PLAYER_TURN_START", this);
    }

    public void setMoveDirection(int dx, int dy) {
        this.moveDX = dx;
        this.moveDY = dy;
    }

    public void update_movement(model.map.Map map) {
        // Only allow a new move if exactly centered on the target tile
        if (Math.abs(pixelX - targetTileX * GameConstants.TILE_SIZE) < 0.01f &&
            Math.abs(pixelY - targetTileY * GameConstants.TILE_SIZE) < 0.01f) {
            if (moveDX != 0 || moveDY != 0) {
                int nextX = targetTileX + moveDX;
                int nextY = targetTileY + moveDY;
                if (Collision.isWalkable(map, nextX, nextY)) {
                    targetTileX = nextX;
                    targetTileY = nextY;
                }
            }
        }
        // Move pixelX/pixelY toward target tile (normalize for diagonal)
        float targetPixelX = targetTileX * GameConstants.TILE_SIZE;
        float targetPixelY = targetTileY * GameConstants.TILE_SIZE;
        float dx = targetPixelX - pixelX;
        float dy = targetPixelY - pixelY;
        float dist = (float)Math.sqrt(dx*dx + dy*dy);
        if (dist > MOVE_SPEED) {
            float ndx = dx / dist;
            float ndy = dy / dist;
            pixelX += MOVE_SPEED * ndx;
            pixelY += MOVE_SPEED * ndy;
        } else {
            pixelX = targetPixelX;
            pixelY = targetPixelY;
            this.position = new utilities.Position(targetTileX, targetTileY);
        }
        // Mark current tile as explored and collect items
        int tileX = (int)Math.floor(pixelX / GameConstants.TILE_SIZE);
        int tileY = (int)Math.floor(pixelY / GameConstants.TILE_SIZE);
        if (map != null && tileX >= 0 && tileY >= 0 && tileX < map.get_width() && tileY < map.get_height()) {
            Tile tile = map.get_tile(tileX, tileY);
            tile.set_explored();
            // Collect items if present
            if (tile.has_items()) {
                List<model.items.Item> items = tile.get_items();
                for (model.items.Item item : new ArrayList<>(items)) {
                    if (collect_item(item)) {
                        tile.remove_item(item);
                        // Optionally notify observers here if needed
                    }
                }
            }
        }
    }

    public void syncToTilePosition(utilities.Position pos) {
        this.position = pos;
        this.pixelX = pos.get_x() * enums.GameConstants.TILE_SIZE;
        this.pixelY = pos.get_y() * enums.GameConstants.TILE_SIZE;
        this.targetTileX = pos.get_x();
        this.targetTileY = pos.get_y();
    }

    public float getPixelX() { return pixelX; }
    public float getPixelY() { return pixelY; }

    // MANDATORY: Additional getters
    public List<Item> get_inventory() {
        return new ArrayList<>(inventory); // Defensive copy
    }

    public int get_inventory_size() {
        return inventory.size();
    }

    public String get_selected_class() {
        return selectedClass;
    }

    public boolean has_item(String itemName) {
        return inventory.stream().anyMatch(item -> item.get_name().equals(itemName));
    }

    public List<Item> get_consumables() {
        return inventory.stream()
            .filter(item -> item instanceof Consumable)
            .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
} 