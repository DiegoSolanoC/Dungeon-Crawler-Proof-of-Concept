# miniRogueDemo
Mini Rogue Demo


Steps to run

1. Clone git repo to desktop
2. Open terminal in Cursor IDE
3. Navigate to root of the folder, miniRogueDemo-main
4. run gradle clean build
6. run gradle jar
7. run Java -jar build/libs/miniRogueDemo-1.0.0.jar or navigate to build/libs directory and double-click the miniRogueDemo-1.0.0.jar file. 
